﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ZaliczeniePawelChec
{
    public partial class Form1 : Form
    {
        MyConnectionSql Cn = new MyConnectionSql();
        string Nazwa, Rodzaj;
        int id = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cn.OpenConnection();
            SqlDataAdapter adapt = new SqlDataAdapter("select * from Praca", Cn.connection);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            dataGridView2.DataSource = dt;
            Cn.CloseConnection();

        }

        private void sweetDataSetBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cn.OpenConnection();

            string query = "INSERT INTO Praca (idPraca,nazwa,rodzaj) values ("+id+",'"+Nazwa+"','"+Rodzaj+"')";

            SqlCommand cmd = new SqlCommand(query, Cn.connection);

            cmd.ExecuteNonQuery();
            textBox1.Clear();
            textBox2.Clear();
            id++;

            Cn.CloseConnection();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Nazwa = textBox1.Text.ToString();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Rodzaj = textBox2.Text.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
