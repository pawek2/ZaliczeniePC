﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows;
using System.Windows.Forms;

namespace ZaliczeniePawelChec
{
    class MyConnectionSql
    {



            public SqlConnection connection;
            public string server;
            public string database;
            public string uid;
            public string password;

            public MyConnectionSql()
            {
                Initialize();

            }
            public void Initialize()
            {
                server = "aimat.pl";
                database = "sweet";
                uid = "marmol";
                password = "!loMraM$";
                string connectionString;
                connectionString = @"SERVER=" + server + ";" + "DATABASE=" +
                database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";

                connection = new SqlConnection(connectionString);
            }
            public bool CloseConnection()
            {
                try
                {
                    connection.Close();
                    return true;
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                    return false;
                }
            }
            public bool OpenConnection()
            {
                try
                {
                    connection.Open();
                    return true;
                }
                catch (SqlException ex)
                {
                    switch (ex.Number)
                    {
                        case 0:
                            MessageBox.Show("Cannot connect to server.  Contact administrator");
                            break;

                        case 1045:
                            MessageBox.Show("Invalid username/password, please try again");
                            break;
                    }
                    return false;
                }

            }

        }
    }



