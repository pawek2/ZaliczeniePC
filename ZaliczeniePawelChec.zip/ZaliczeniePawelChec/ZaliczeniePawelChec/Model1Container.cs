﻿namespace ZaliczeniePawelChec
{
    internal class Model1Container
    {
        public object Praca { get; internal set; }
    }
}